MINI VR SOCIAL - PROJETO ANDROID

Este projeto empacota o arquivo HTML original em um app Android usando WebView.
O HTML original foi mantido em app/src/main/assets/index.html.

COMO GERAR O APK NO ANDROID (sem PC):
1. Instale o AndroidIDE no seu Android a partir da fonte oficial do projeto.
2. Extraia este ZIP para uma pasta do aparelho.
3. No AndroidIDE, abra/importa a pasta minivr-android (a pasta que contém settings.gradle).
4. Aguarde o Gradle baixar as dependências. É necessária internet na primeira compilação.
5. Escolha a tarefa assembleDebug e execute Build/Run.
6. O APK de teste será criado em app/build/outputs/apk/debug/app-debug.apk.

OBSERVAÇÕES:
- Este ambiente não tem Android SDK/Gradle instalado, então não foi possível compilar nem assinar um APK aqui.
- O HTML usa bibliotecas Three.js carregadas de CDNs externos; por isso o app precisa de internet para carregar essas bibliotecas.
- Este pacote é um projeto Android pronto para compilar, NÃO é um APK instalável ainda.
