VRGO - PROJETO ANDROID (WEBVIEW)

Este ZIP contém o projeto Android que empacota o HTML original Mini VR Social.index.zip.
Nome do aplicativo: VRGO.
Ícone: imagem VRGO/Kermit fornecida na conversa, adaptada para os tamanhos de ícone Android.

IMPORTANTE:
- Este é um PROJETO ANDROID para compilar; não é um APK pronto.
- O ambiente de criação não possui Android SDK/Gradle, então o APK não foi compilado aqui.
- O HTML foi colocado em app/src/main/assets/index.html.
- O conteúdo original foi mantido. Bibliotecas e recursos externos usados pelo HTML ainda podem exigir internet.

Para AndroidForge:
1. Envie este ZIP como projeto Android de origem.
2. Selecione a variante debug e inicie o build.
3. Se o workflow for cancelado, abra a execução no GitHub Actions e veja o motivo/log.
