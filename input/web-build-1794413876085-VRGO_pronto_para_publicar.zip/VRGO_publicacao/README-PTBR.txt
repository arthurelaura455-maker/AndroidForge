VRGO — pacote inicial para publicar online

O QUE VEM NESTE PACOTE
- public/index.html: jogo VRGO enviado nesta conversa.
- server.js: servidor HTTP + WebSocket para salas e jogadores.
- public/skins.json: lista inicial vazia de skins. O jogo usa o avatar provisório até adicionar arquivos .glb.
- package.json: dependências (Express, Three.js e ws).
- render.yaml: configuração inicial do serviço no Render.

IMPORTANTE
Este pacote prepara o multiplayer básico para salas, movimento, chat e pedidos de amizade em memória. Não inclui modelos .glb de avatar. A lista de amigos e as salas são mantidas em memória e podem ser perdidas quando o serviço reiniciar. O plano gratuito do Render pode suspender o servidor quando estiver sem uso. Para muitos jogadores, estabilidade contínua e dados persistentes, será necessário planejar hospedagem e armazenamento adequados.

PUBLICAR PELO ANDROID OU PC
1. Extraia o ZIP no aparelho ou computador.
2. Entre em https://github.com/ e crie um repositório novo chamado vrgo-online. Deixe-o privado se preferir.
3. Envie todos os arquivos e pastas que estão dentro de VRGO_publicacao para a raiz do repositório (não envie a pasta externa inteira como uma subpasta).
4. Entre em https://render.com/ e crie/entre na sua conta.
5. No painel do Render, escolha New > Web Service e conecte o repositório GitHub vrgo-online.
6. Configure:
   - Runtime: Node
   - Build Command: npm install
   - Start Command: npm start
   - Health Check Path: /healthz
   - Plan: Free para teste inicial
7. Clique em Create Web Service e aguarde o deploy terminar com status Live.
8. Abra o endereço *.onrender.com que o Render mostrar. Esse será o link do jogo.

TESTE
- Abra o link em dois dispositivos/navegadores diferentes.
- Digite nomes diferentes (mínimo 2 letras).
- Entre no Lobby ou crie uma sala pública e use o código para o segundo jogador entrar.
- Se o serviço tiver acabado de acordar, espere alguns instantes e tente novamente.

OBSERVAÇÕES TÉCNICAS
- O servidor aceita WebSocket no caminho /ws e o navegador usa wss:// automaticamente quando o site está em HTTPS.
- A biblioteca Three.js é servida pelo próprio projeto em /lib/three.
- Para adicionar skins: coloque os arquivos .glb em public/skins/ e liste os nomes exatos em public/skins.json, por exemplo: ["avatar.glb"].
- Não compartilhe dados pessoais no nome do jogador nem no chat público.
