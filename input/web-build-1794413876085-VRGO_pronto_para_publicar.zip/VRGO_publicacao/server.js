import express from 'express';
import http from 'node:http';
import { WebSocketServer, WebSocket } from 'ws';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: '/ws' });
const PORT = Number(process.env.PORT || 10000);

app.get('/healthz', (_req, res) => res.status(200).send('VRGO online'));
app.use('/lib/three', express.static(path.join(__dirname, 'node_modules/three')));
app.use(express.static(path.join(__dirname, 'public')));
app.get('*', (_req, res) => res.sendFile(path.join(__dirname, 'public/index.html')));

let nextId = 1;
const clients = new Map(); // ws -> player
const rooms = new Map();
const users = new Map(); // normalized name -> transient friend data

const clean = (v, max = 80) => String(v ?? '').replace(/[<>\u0000-\u001f]/g, '').trim().slice(0, max);
const norm = v => clean(v, 16).toLocaleLowerCase('pt-BR');
const send = (ws, data) => { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(data)); };
const roomSummary = () => [...rooms.values()].filter(r => !r.priv && r.code !== 'LOBBY').map(r => ({ code: r.code, name: r.name, n: r.players.size }));
function updateRooms() {
  const data = { t: 'rooms', rooms: roomSummary() };
  for (const ws of clients.keys()) send(ws, data);
}
function onlineByName(name) {
  const key = norm(name);
  for (const p of clients.values()) if (norm(p.name) === key) return p;
  return null;
}
function updateFriends(user) {
  const list = [...user.friends].map(key => {
    const online = onlineByName(key);
    return { name: users.get(key)?.name || key, online: !!online, room: online?.room?.code || null };
  });
  const req = [...user.requests].map(key => users.get(key)?.name || key);
  send(user.ws, { t: 'friends', list, req });
}
function leaveRoom(p) {
  const room = p.room;
  if (!room) return;
  room.players.delete(p.ws);
  for (const ws of room.players.keys()) send(ws, { t: 'pleave', id: p.id });
  p.room = null;
  if (room.players.size === 0 && room.code !== 'LOBBY') rooms.delete(room.code);
  updateRooms();
}
function uniqueCode() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code;
  do { code = Array.from({ length: 5 }, () => chars[Math.floor(Math.random() * chars.length)]).join(''); }
  while (rooms.has(code));
  return code;
}
function joinRoom(p, room) {
  if (!room) return send(p.ws, { t: 'err', m: 'Sala não encontrada.' });
  if (room.players.size >= 16 && !room.players.has(p.ws)) return send(p.ws, { t: 'err', m: 'Essa sala está cheia (16 jogadores).' });
  leaveRoom(p);
  const others = [...room.players.values()].map(q => ({ id: q.id, name: q.name, skin: q.skin, flip: q.flip, s: [q.x, q.y, q.z, q.ry] }));
  room.players.set(p.ws, p);
  p.room = room;
  send(p.ws, { t: 'joined', code: room.code, name: room.name, priv: room.priv, players: others });
  for (const q of room.players.values()) if (q !== p) send(q.ws, { t: 'pjoin', p: { id: p.id, name: p.name, skin: p.skin, flip: p.flip, s: [p.x, p.y, p.z, p.ry] } });
  updateRooms();
  for (const q of room.players.values()) updateFriends(q);
}
function removeClient(ws) {
  const p = clients.get(ws);
  if (!p) return;
  leaveRoom(p);
  clients.delete(ws);
  const user = users.get(p.key);
  if (user?.ws === ws) user.ws = null;
  for (const q of clients.values()) updateFriends(q);
}

wss.on('connection', ws => {
  ws.on('message', raw => {
    let m;
    try { m = JSON.parse(raw.toString()); } catch { return send(ws, { t: 'err', m: 'Mensagem inválida.' }); }
    const p = clients.get(ws);

    if (m.t === 'hello') {
      if (p) return;
      const name = clean(m.name, 16);
      if (name.length < 2) return send(ws, { t: 'err', m: 'Digite um nome com pelo menos 2 letras.' });
      const key = norm(name);
      const user = users.get(key) || { name, friends: new Set(), requests: new Set(), ws: null };
      user.name = name;
      user.ws = ws;
      users.set(key, user);
      const player = { id: nextId++, ws, name, key, skin: clean(m.skin, 100), flip: !!m.flip, room: null, x: 0, y: 0, z: 0, ry: 0, mv: 0 };
      clients.set(ws, player);
      send(ws, { t: 'welcome', id: player.id, rooms: roomSummary() });
      updateFriends(player);
      for (const q of clients.values()) if (q !== player) updateFriends(q);
      return;
    }
    if (!p) return send(ws, { t: 'err', m: 'Conecte-se novamente.' });

    switch (m.t) {
      case 'join': {
        const code = clean(m.code, 12).toUpperCase();
        if (code === 'LOBBY') {
          let lobby = rooms.get('LOBBY');
          if (!lobby) { lobby = { code: 'LOBBY', name: 'Lobby', priv: false, players: new Map() }; rooms.set('LOBBY', lobby); }
          joinRoom(p, lobby);
        } else joinRoom(p, rooms.get(code));
        break;
      }
      case 'create': {
        leaveRoom(p);
        const code = uniqueCode();
        const room = { code, name: clean(m.name, 32) || `Sala de ${p.name}`, priv: !!m.priv, players: new Map() };
        rooms.set(code, room);
        joinRoom(p, room);
        break;
      }
      case 'joinFriend': {
        const friend = onlineByName(m.name);
        if (!friend?.room) return send(ws, { t: 'info', m: 'Esse amigo não está em uma sala.' });
        if (!p.friends?.has(friend.key) && !users.get(p.key)?.friends.has(friend.key)) return send(ws, { t: 'err', m: 'Adicione essa pessoa como amiga primeiro.' });
        joinRoom(p, friend.room);
        break;
      }
      case 'skin': {
        p.skin = clean(m.skin, 100); p.flip = !!m.flip;
        if (p.room) for (const q of p.room.players.values()) if (q !== p) send(q.ws, { t: 'pskin', id: p.id, skin: p.skin, flip: p.flip });
        break;
      }
      case 's': {
        if (!p.room || !Array.isArray(m.s) || m.s.length < 5) break;
        const vals = m.s.slice(0, 5).map(Number);
        if (!vals.every(Number.isFinite)) break;
        [p.x, p.y, p.z, p.ry] = vals.slice(0, 4);
        p.mv = Number(m.s[4]) ? 1 : 0;
        const data = { t: 's', p: [...p.room.players.values()].filter(q => q !== p).map(q => [q.id, q.x, q.y, q.z, q.ry, q.mv]) };
        // Send this player's position to every other player in the room.
        for (const q of p.room.players.values()) if (q !== p) send(q.ws, { t: 's', p: [[p.id, p.x, p.y, p.z, p.ry, p.mv]] });
        break;
      }
      case 'chat': {
        const message = clean(m.m, 200);
        if (!message || !p.room) break;
        for (const q of p.room.players.values()) send(q.ws, { t: 'chat', from: p.name, m: message });
        break;
      }
      case 'fAdd': {
        const target = onlineByName(m.name);
        if (!target || target.key === p.key) return send(ws, { t: 'info', m: 'Não encontrei essa pessoa online.' });
        const a = users.get(p.key), b = users.get(target.key);
        if (a.friends.has(target.key)) return send(ws, { t: 'info', m: 'Essa pessoa já está na sua lista.' });
        b.requests.add(p.key); updateFriends(target); send(ws, { t: 'info', m: 'Pedido de amizade enviado.' });
        break;
      }
      case 'fAccept': {
        const targetKey = norm(m.name), a = users.get(p.key), b = users.get(targetKey);
        if (!b || !a.requests.has(targetKey)) break;
        a.requests.delete(targetKey); a.friends.add(targetKey); b.friends.add(p.key);
        if (b.ws && clients.has(b.ws)) updateFriends({ ...b, ws: b.ws });
        updateFriends(p);
        break;
      }
      case 'fDeny': users.get(p.key).requests.delete(norm(m.name)); updateFriends(p); break;
      case 'fRemove': {
        const key = norm(m.name), a = users.get(p.key), b = users.get(key);
        a.friends.delete(key); b?.friends.delete(p.key); updateFriends(p);
        if (b?.ws && clients.has(b.ws)) updateFriends({ ...b, ws: b.ws });
        break;
      }
      default: break;
    }
  });
  ws.on('close', () => removeClient(ws));
  ws.on('error', () => removeClient(ws));
});

server.listen(PORT, '0.0.0.0', () => console.log(`VRGO ouvindo na porta ${PORT}`));
